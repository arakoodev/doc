package com.app.openai.prompt;

public interface PromptTemplate {

  String getPrompt();
}
