package com.edgechain.lib.openai.prompt;

public interface PromptTemplate {

  String getPrompt();
}
