package com.edgechain.lib.chains;

public abstract class Retrieval {

  public abstract void upsert(String input);
}
