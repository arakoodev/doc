package com.edgechain.lib.jsonnet.exceptions;

public class JsonnetArgException extends Exception {

  public JsonnetArgException(String message) {
    super(message);
  }
}
