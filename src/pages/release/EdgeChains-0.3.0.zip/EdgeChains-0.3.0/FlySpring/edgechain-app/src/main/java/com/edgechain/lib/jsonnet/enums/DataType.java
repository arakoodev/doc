package com.edgechain.lib.jsonnet.enums;

public enum DataType {
  INTEGER,
  STRING,
  BOOLEAN
}
