package com.edgechain.lib.request.exception;

public class InvalidArkRequest extends RuntimeException {

  public InvalidArkRequest(String message) {
    super(message);
  }
}
