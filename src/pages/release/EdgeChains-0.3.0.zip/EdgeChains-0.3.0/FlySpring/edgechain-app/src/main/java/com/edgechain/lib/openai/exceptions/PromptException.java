package com.edgechain.lib.openai.exceptions;

public class PromptException extends RuntimeException {

  public PromptException(String message) {
    super(message);
  }
}
