package com.edgechain.lib.chunk.enums;

public enum LangType {
  EN,
  FR,
  DE,
  IT,
  NL
}
