package com.edgechain.lib.jsonnet.exceptions;

public class JsonnetLoaderException extends RuntimeException {

  public JsonnetLoaderException(String message) {
    super(message);
  }
}
