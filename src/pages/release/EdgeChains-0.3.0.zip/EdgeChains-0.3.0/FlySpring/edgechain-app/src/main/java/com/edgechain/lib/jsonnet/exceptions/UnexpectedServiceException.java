package com.edgechain.lib.jsonnet.exceptions;

public class UnexpectedServiceException extends RuntimeException {

  public UnexpectedServiceException(String message) {
    super(message);
  }
}
